# Rain Modules

These files are used by [CloudFormation
Rain](https://github.com/aws-cloudformation/rain) to inject re-useable code
into templates with the `!Rain::Module` directive.

They have a `.yml` extension instead of a `.yaml` extension to exclude them 
from automation like formatting and linting.


