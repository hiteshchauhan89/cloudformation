# A CloudFormation template to install GitLab on an EC2 instance

This template creates a VPC and an EC2 instance with a self-hosted instance of GitLab.




